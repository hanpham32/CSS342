/*
Project 2 - CSS342
Hannah Pham
10/28/2022
catalan.h
*/

#ifndef CATALAN_H_
#define CATALAN_H_

class Catalan
{
public:
    // Constructors
    Catalan();
    Catalan(int n);

    int ComputeCatalan(int n);

    // friend istream &operator>>(istream &is, int n);

private:
};
#endif